﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using BusinessLayer;
using ConsoleTables;

namespace MovieManagement
{
    public class MovieLanguagePL
    {
        public static void ViewMovieLanguage()
        {
            Console.Clear();
            Console.WriteLine("Displaying all the movies and the language they are in : ");
            List<MovieLanguage> movieLanguageList = new List<MovieLanguage>();
            try
            {
                MovieLanguageBL movieLanguageBLObj = new MovieLanguageBL();
                movieLanguageList = movieLanguageBLObj.ListAllMovieLanguage();
                var table = new ConsoleTable("Movie Language Id","Movie ID", "Language Name");
                foreach (MovieLanguage me in movieLanguageList)
                {
                    table.AddRow(me.Id,me.MovieID, me.LanguageID);
                }
                table.Write();
                Console.WriteLine();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public static void AddMovieLanguage()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Add Movie Language Portal");
            Console.WriteLine("Please Enter the Movie ID and Language ID : ");
            MovieLanguage movieLanguageObj = new MovieLanguage();
            movieLanguageObj.MovieID = Convert.ToInt32(Console.ReadLine());
            movieLanguageObj.LanguageID = Convert.ToInt32(Console.ReadLine());
            bool added = false;
            try
            {
                MovieLanguageBL movieLanguageBLObj = new MovieLanguageBL();
                added = movieLanguageBLObj.InsertMovieLanguage(movieLanguageObj);
                if (added == true)
                {
                    Console.WriteLine("New Movie and Language was added !");
                }
                else
                {
                    Console.WriteLine("New Movie and Language was not added !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateMovieLanguage()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the update Movie Language Portal");
            MovieLanguage movieLanguageObj = new MovieLanguage();
            Console.WriteLine("Please Enter the MovieLanguage ID :");
            movieLanguageObj.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter the Movie ID :");
            movieLanguageObj.MovieID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter the Language ID :");
            movieLanguageObj.LanguageID = Convert.ToInt32(Console.ReadLine());
            bool updated = false;
            try
            {
                MovieLanguageBL movieLanguageBLObj = new MovieLanguageBL();
                updated = movieLanguageBLObj.UpdateMovieLanguage(movieLanguageObj);
                if (updated == true)
                {
                    Console.WriteLine("Movie and Language was updated !");
                }
                else
                {
                    Console.WriteLine("Movie and Language was not updated !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteMovieLanguage()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Delete Movie Language Portal");
            Console.WriteLine("Please Enter the MovieLanguage ID to be deleted");
            int movieId = Convert.ToInt32(Console.ReadLine());
            bool added = false;
            try
            {
                MovieLanguageBL movieLanguageBLObj = new MovieLanguageBL();
                added = movieLanguageBLObj.DeleteMovieLanguage(movieId);
                if (added == true)
                {
                    Console.WriteLine("Movie and Language was deleted !");
                }
                else
                {
                    Console.WriteLine("Movie and Language was not deleted !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
