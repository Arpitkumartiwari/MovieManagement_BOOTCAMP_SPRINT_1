﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer;
using ConsoleTables;
using Entities;
namespace MovieManagement
{
    public class CustomerPL
    {
        public static void CustomerRegistration()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Custoer Registration Portal !");
            User userObj = new User();
            Console.WriteLine("Please Enter Your Name");
            userObj.Name = Console.ReadLine();
            Console.WriteLine("Please Enter Your Password");
            userObj.Password = Console.ReadLine();
            bool registered = false;
            try
            {
                UserBL userBLObj = new UserBL();
                registered = userBLObj.AddCustomer(userObj);
                if (registered == true)
                {
                    Console.WriteLine("New Customer Was Registeres\n Now You Can Login...");
                }
                else
                {
                    Console.WriteLine("New user is Not Registered !");
                }

            }
            catch (FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void GetAllMovies()
        {
            Console.Clear();
            Console.WriteLine("Displaying all the movies in the repository !");
            List<Movie> movielist = new List<Movie>();
            try
            {
                MovieBL movieBLObj = new MovieBL();
                movielist = movieBLObj.ListMovies();
                var table = new ConsoleTable("Name", "Category Name","Rating", "Lead Actor","Release Year", "Description","Budget", "Duration");
                foreach (Movie me in movielist)
                {
                    table.AddRow(me.Name, me.CategoryName,me.Rating, me.LeadActor,me.ReleaseYear, me.Description,me.Budget, me.Duration);
                }
                table.Write();
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByName()
        {
            Console.Clear();
            Console.Write("Enter the Movie Name : ");
            string name = Console.ReadLine();
            List<Movie> searchList = new List<Movie>();
            try
            {
                MovieBL movieBLObj = new MovieBL();
                searchList = movieBLObj.SearchMovieName(name);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);

                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByReleaseYear()
        {
            Console.Clear();
            Console.Write("Enter the Movie Release year : ");
            int year = Convert.ToInt32( Console.ReadLine());
            List<Movie> searchList = new List<Movie>();
            try
            {
                MovieBL movieBLObj = new MovieBL();
                searchList = movieBLObj.SearchMoviesByReleaseYear(year);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);

                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!");
                }
            }
            catch (FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByCategory()
        {
            Console.Clear();
            Console.Write("Enter the Movie Category : ");
            string category = Console.ReadLine();
            List<Movie> searchList = new List<Movie>();
            try
            {
                MovieBL movieBLObj = new MovieBL();
                searchList = movieBLObj.SearchByCategory(category);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);
                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!");
                }
            }
            catch (FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByLanguage()
        {
            Console.Clear();
            List<Movie> searchList = new List<Movie>();
            try
            {
                Console.Write("Enter the Movie Language : ");
                string language = Console.ReadLine();
                MovieBL movieBLObj = new MovieBL();
                searchList = movieBLObj.SearchMoviesByLanguage(language);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);
                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!");
                }
            }
            catch (FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByMovieRating()
        {
            Console.Clear();
            List<Movie> searchList = new List<Movie>();
            try
            {
                    Console.Write("Enter the Movie Rating : ");
                    int rating = Convert.ToInt32(Console.ReadLine());
                    MovieBL movieBLObj = new MovieBL();
                    searchList = movieBLObj.SearchMoviesByRating(rating);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);
                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!!!");
                }
            }

            catch(FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchByLeadActor()
        {
            Console.Clear();
            List<Movie> searchList = new List<Movie>();
            try
            {
                Console.Write("Enter the Movie Name : ");
                string actorName = Console.ReadLine();
                MovieBL movieBLObj = new MovieBL();
                searchList = movieBLObj.SearchMoviesByLeadActor(actorName);
                if (searchList.Count>0)
                {
                    var table = new ConsoleTable("Name", "Category Name", "Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                    foreach (Movie me in searchList)
                    {
                        table.AddRow(me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);
                    }
                    table.Write();
                    Console.WriteLine();
                }
                else
                {
                    throw new Exception("Record Not Found !!");
                }
            }
            catch (FormatException)
            {
                throw new Exception("Please enter the Correct Details !");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
