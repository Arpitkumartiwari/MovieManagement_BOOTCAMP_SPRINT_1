﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using BusinessLayer;
using ConsoleTables;

namespace MovieManagement
{
    public class LanguagePL
    {
        public static void ViewLanguage()
        {
            List<Language> languageList = new List<Language>();
            try
            {
                LanguageBL languageBLObj = new LanguageBL();
                languageList = languageBLObj.GetAllLanguageBL();

                var table = new ConsoleTable("Language ID","Name");
                foreach (Language me in languageList)
                {
                    table.AddRow(me.Id,me.Name);
                }
                table.Write();
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AddLanguage()
        {
            Console.WriteLine("Please enter the new Language !");
            Language languageObj = new Language();
            languageObj.Name = Console.ReadLine();
            bool added = false;
            try
            {
                LanguageBL languageBLObj = new LanguageBL();
                added = languageBLObj.AddLanguageBL(languageObj);
                if (added == true)
                {
                    Console.WriteLine(languageObj.Name + "Language was ADDED !");
                }
                else
                {
                    Console.WriteLine(languageObj.Name + "Language was NOT ADDED!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteLanguage()
        {
            Console.Write("Please Enter the Language ID to be Deleted : ");
            try
            {
                LanguageBL languageBLObj = new LanguageBL();
                Language languageObj = new Language();
                languageObj.Id = Convert.ToInt32(Console.ReadLine());
                bool deleted = false;
                deleted = languageBLObj.DeleteLanguageBL(languageObj);
                if (deleted == true)
                {
                    Console.WriteLine("Language Was Deleted !");
                }
                else
                {
                    Console.WriteLine("Language Was Not Deleted !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
