﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entities;
using DAL;
using BusinessLayer;
using System.Security;
using System.Runtime.InteropServices;

namespace MovieManagement
{
    class Program
    {
        public static SecureString PasswordMasking()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else if (i.KeyChar != '\u0000') // KeyChar == '\u0000' if the key pressed does not correspond to a printable character, e.g. F1, Pause-Break, etc
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }
            return pwd;
        }

        static String SecureStringToString(SecureString value)
        {
            IntPtr bstr = Marshal.SecureStringToBSTR(value);

            try
            {
                return Marshal.PtrToStringBSTR(bstr);
            }
            finally
            {
                Marshal.FreeBSTR(bstr);
            }
        }

        public static void LogIn()
        {
            try
            {
                User userObj = new User();
                UserBL userBlObj = new UserBL();
                Console.WriteLine("Enter UserName");
                userObj.Name = Console.ReadLine();
                Console.WriteLine("Enter Password");
                userObj.Password = SecureStringToString(PasswordMasking());
                int Role = userBlObj.LogIn(userObj);

                if (Role == 1)
                {
                    Console.Clear();
                   AdminLogin(userObj.Name);
                }
                else if (Role == 2)
                {
                    Console.Clear();
                    CustomerLogin(userObj.Name);
                }
                else
                {
                    Console.WriteLine("\nWrong User Id or Password\nPlease Enter the Correct ID and Password to Login !\n");
                    Console.Clear();
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }
        }

        public static void AdminRegistration()
        {
            Console.Clear();
            Console.WriteLine("Entering into the Adming Registration Portal !");
            User userObj = new User();
            Console.WriteLine("Please Enter Your Name");
            userObj.Name = Console.ReadLine();
            Console.WriteLine("Please Enter Your Password");
            userObj.Password = Console.ReadLine();
            bool registered = false;
            try
            {
                UserBL userBLObj = new UserBL();
                registered = userBLObj.AddAdmin(userObj);
                if (registered == true)
                {
                    Console.WriteLine("\nNew Admin Was Registeres\n Now You Can Login...\n");
                }
                else
                {
                    Console.WriteLine("\nNew Admin is Not Registered !\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AdminLogin(string Name)
        {
            Console.Clear();
            Console.WriteLine("Entering into the Admin Login Portal !");
            Console.WriteLine("Welcome " + Name + " to Movie Management Portal\n___________________________________________");
            try
            {
                do
                {
                    Console.WriteLine("What Operation you would like to perform.");
                    Console.WriteLine("\n1.Register a new Admin.\n2.Register a New Customer \n3.Search Movies. \n4.Movies Operation. \n5.Movie Category Operations.");
                    Console.WriteLine("6.Language Operations. \n7.MovieLanguageOperation\n8. LogOut");
                    Console.Write("\nPlease enter the option Number to perform the operation :-");
                    int Option = Convert.ToInt32(Console.ReadLine());
                    switch (Option)
                    {
                        case 1:
                            Console.Clear();
                            AdminRegistration();
                            break;
                        case 2:
                            Console.Clear();
                            CustomerPL.CustomerRegistration();
                            break;
                        case 3:
                            Console.Clear();
                            AdminMovieSearch();
                            break;
                        case 4:
                            Console.Clear();
                            AdminMovieOperation();
                            break;
                        case 5:
                            Console.Clear();
                            CategoryOperation();
                            break;
                        case 6:
                            Console.Clear();
                            LanguageOperation();
                            break;
                        case 7:
                            Console.Clear();
                            MovieLanguageOperation();
                            break;
                        case 8: Console.Clear();
                            return;
                        default:
                            Console.WriteLine("Invalid option");
                            break;
                    }
                }
                while (true);
            }

            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                AdminLogin(Name);
            }
        }

        public static void CustomerLogin(string Name)
        {
            Console.Clear();
            Console.WriteLine("Entering into the Customer Login Portal !");
            Console.WriteLine("\nWelcome " + Name);
            try
            {
                do
                {
                    Console.WriteLine("Choose what Operation You want to perform.");
                    Console.WriteLine("1.Get All Movies. \n2.Search Movie by Name. \n3.Search Movie by Release Year.");
                    Console.WriteLine("4.Search Movie by Category \n5.Search Movie by Language \n6.Search Movie by Rating");
                    Console.WriteLine("7.Search Movie by Lead Actor \n8.Log Out");
                    int Option = Convert.ToInt32(Console.ReadLine());
                    switch (Option)
                    {
                        case 1:
                            Console.Clear(); CustomerPL.GetAllMovies();
                            break;
                        case 2:
                            Console.Clear();
                            CustomerPL.SearchByName();
                            break;
                        case 3:
                            Console.Clear(); CustomerPL.SearchByReleaseYear();
                            break;
                        case 4:
                            Console.Clear(); CustomerPL.SearchByCategory();
                            break;
                        case 5:
                            Console.Clear(); CustomerPL.SearchByLanguage();
                            break;
                        case 6:
                            Console.Clear(); CustomerPL.SearchByMovieRating();
                            break;
                        case 7:
                            Console.Clear(); CustomerPL.SearchByLeadActor();
                            break;
                        case 8: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid option");
                            break;
                    }
                }
                while (true);
            }

            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                CustomerLogin(Name);
            }
        }

        public static void AdminMovieOperation()
        {
            Console.WriteLine("Entering into the Movie Operation Portal !");
            try
            {
                do
                {
                    Console.WriteLine("Choose Movie Operation");
                    Console.WriteLine("1.View All Movies. \n2.Add Movie. \n3.Update Movie. \n4.Delete Movie.\n5.Back");
                    int Option = Convert.ToInt32(Console.ReadLine());
                    switch (Option)
                    {
                        case 1:
                            Console.Clear(); MoviePL.ViewAllMovies();
                            break;
                        case 2:
                            Console.Clear(); MoviePL.Addmovie();
                            break;
                        case 3:
                            Console.Clear(); MoviePL.UpdateMovie();
                            break;
                        case 4:
                            Console.Clear(); MoviePL.DeleteMovie();
                            break;
                        case 5: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid option");
                            break;
                    }
                }
                while (true);
            }

            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                AdminMovieOperation();
            }
        }

        public static void AdminMovieSearch()
        {
            try
            {
                do
                {
                    Console.WriteLine("Choose your search options");
                    Console.WriteLine("1.View All Movies. \n2.Search Movie by Name. \n3.Search Movie by Release Year.");
                    Console.WriteLine("4.Search Movie by Category \n5.Search Movie by Language \n6.Search Movie by Rating");
                    Console.WriteLine("7.Search Movie by Lead Actor \n8.Back");
                    int Choice = Convert.ToInt32(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:
                            Console.Clear();
                            MoviePL.ViewAllMovies();
                            break;
                        case 2:
                            Console.Clear();
                            CustomerPL.SearchByName();
                            break;
                        case 3:
                            Console.Clear();
                            CustomerPL.SearchByReleaseYear();
                            break;
                        case 4:
                            Console.Clear();
                            CustomerPL.SearchByCategory();
                            break;
                        case 5:
                            Console.Clear();
                            CustomerPL.SearchByLanguage();
                            break;
                        case 6:
                            Console.Clear();
                            CustomerPL.SearchByMovieRating();
                            break;
                        case 7:
                            Console.Clear();
                            CustomerPL.SearchByLeadActor();
                            break;
                        case 8: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid option");
                            break;
                    }
                }
                while (true);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                AdminMovieSearch();
            }
        }

        public static void CategoryOperation()
        {
            try
            {
                do
                {
                    Console.WriteLine("Choose Options for category operation.");
                    Console.WriteLine("1. View All Categories. \n2. Add Category\n3.Update Category\n4. Delete Category.\n5. Back.");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            Console.Clear(); CategoryPL.ViewCategory();
                            break;
                        case 2:
                            Console.Clear(); CategoryPL.AddCategory();
                            break;
                        case 3:
                            Console.Clear(); CategoryPL.UpdateCategory();
                            break;
                        case 4:
                            Console.Clear(); CategoryPL.DeleteCategory();
                            break;
                        case 5: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid Option");
                            break;
                    }
                }
                while (true);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                CategoryOperation();
            }
        }
        
        public static void MovieLanguageOperation()
        {
            try
            {
                do
                {
                    Console.WriteLine("Choose Options for MovieLanguage operation.");
                    Console.WriteLine("1.View All Movies \n2. View Movie Language Table\n3.Add Movie Language\n4.Update Movie Language \n5.Delete Movie Language\n6. Back.");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            Console.Clear(); MoviePL.ViewAllMovies();
                            break;
                        case 2:
                            Console.Clear(); MovieLanguagePL.ViewMovieLanguage();
                            break;
                        case 3:
                            Console.Clear(); MovieLanguagePL.AddMovieLanguage();
                            break;
                        case 4:
                            Console.Clear(); MovieLanguagePL.UpdateMovieLanguage();
                            break;
                        case 5:
                            Console.Clear(); MovieLanguagePL.DeleteMovieLanguage();
                            break;
                        case 6: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid Option");
                            break;
                    }
                }
                while (true);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                MovieLanguageOperation();
            }
        }

        public static void LanguageOperation()
        {
            try
            {
                do
                {
                    Console.WriteLine("Choose Options for Language operation.");
                    Console.WriteLine("1. View All Languages. \n2. Add Language\n3. Delete Language.\n4. Back.");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            Console.Clear(); LanguagePL.ViewLanguage();
                            break;
                        case 2:
                            Console.Clear(); LanguagePL.AddLanguage();
                            break;
                        case 3:
                            Console.Clear(); LanguagePL.DeleteLanguage();
                            break;
                        case 4: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid Option");
                            break;
                    }
                }
                while (true);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please Enter the Correct Option !!\nPress Enter to Continue");
                Console.ReadKey();
                LanguageOperation();
            }
        }

        public static void MainMenu()
        {
            try
            {
                do
                {
                    Console.WriteLine("Dou you want to Register or LogIn?");
                    Console.WriteLine("1.LogIn\n2.Register Customer\n3.Exit");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.Clear();
                            LogIn();
                            break;
                        case 2:
                            Console.Clear();
                            CustomerPL.CustomerRegistration();
                            break;
                        case 3: Console.Clear(); return;
                        default:
                            Console.WriteLine("Invalid Input");
                            break;
                    }
                }
                while (true);
            }
            catch (FormatException )
            {
                throw new Exception("Please Enter Correct Option !");
            }
        }

        static void Main(string[] args)
        {
            try
            {
                MainMenu();
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
                
                MainMenu();
            }
        }
    }
}
