﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using BusinessLayer;
using ConsoleTables;

namespace MovieManagement
{
    public class MoviePL
    {
        public static void ViewAllMovies()
        {
            Console.WriteLine("Displaying All the Movie In the Repository !");
            List<Movie> movielist = new List<Movie>();
            try
            {
                MovieBL movieBLObj = new MovieBL();
                movielist = movieBLObj.ListMovies();
                var table = new ConsoleTable("Id","Name", "Category Name","Rating", "Lead Actor", "Release Year", "Description", "Budget", "Duration");
                foreach (Movie me in movielist)
                {
                    table.AddRow(me.Id,me.Name, me.CategoryName, me.Rating, me.LeadActor, me.ReleaseYear, me.Description, me.Budget, me.Duration);
                }
                table.Write();
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void Addmovie()
        {
            Console.Clear();
            Console.WriteLine("Entering into the Add Movies Portal !");
            try
            {
                CategoryPL.ViewCategory();
                Console.WriteLine("---------------------------------------------");
                Movie movieObj = new Movie();
                Console.Write("Enter New Movie Name : ");
                movieObj.Name = Console.ReadLine();

                Console.Write("Enter New Movie CategoryId : ");
                movieObj.CategoryId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter New Movie Rating (out Of 10) : ");
                movieObj.Rating = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter New Movie Lead Actor (press ',' after every actor) : ");
                movieObj.LeadActor = Console.ReadLine();

                Console.Write("Enter New Movie Release Year : ");
                movieObj.ReleaseYear = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter New Movie Movie Description : ");
                movieObj.Description = Console.ReadLine();

                Console.Write("Enter New Movie Movie Budget (In Cr) : ");
                movieObj.Budget = Console.ReadLine();

                Console.Write("Enter New Movie Movie Duration (In Minutes) : ");
                movieObj.Duration = Convert.ToInt32(Console.ReadLine());
                bool added = false;
                MovieBL movieBLObj = new MovieBL();
                added = movieBLObj.AddMovies(movieObj);
                if (added == true)
                {
                    Console.WriteLine("New Movie Was Added !");
                }
                else
                {
                    Console.WriteLine("New Movie Was Not Added !");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public static void UpdateMovie()
        {
            Console.Clear();
            Console.WriteLine("Entering into the Update Movies Portal !");
            try
            {
                ViewAllMovies();
                CategoryPL.ViewCategory();
                Console.WriteLine("---------------------------------------------");
                Movie movieObj = new Movie();

                Console.Write("Enter The Movie ID :");
                movieObj.Id = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Movie Name : ");
                movieObj.Name = Console.ReadLine();

                Console.Write("Enter Movie CategoryId : ");
                movieObj.CategoryId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Movie Rating (out Of 10) : ");
                movieObj.Rating = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Movie Lead Actor (press ',' after every actor) : ");
                movieObj.LeadActor = Console.ReadLine();

                Console.Write("Enter Movie Release Year : ");
                movieObj.ReleaseYear = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Movie Movie Description : ");
                movieObj.Description = Console.ReadLine();

                Console.Write("Enter Movie Movie Budget (In Cr) : ");
                movieObj.Budget = Console.ReadLine();

                Console.Write("Enter Movie Movie Duration (In Minutes) : ");
                movieObj.Duration = Convert.ToInt32(Console.ReadLine());
                bool updated = false;
                MovieBL movieBLObj = new MovieBL();
                updated = movieBLObj.UpdateMovies(movieObj);
                if (updated)
                {
                    Console.WriteLine("Movie Was updated !");
                }
                else
                {
                    Console.WriteLine("Movie Was Not updated !");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }
        public static void DeleteMovie()
        {
            Console.Clear();
            Console.WriteLine("Entering into the Delete Movies Portal !");
            try
            {
                ViewAllMovies();
                Console.WriteLine("Please Enter the Movie Id to be Deleted");
                int movieId = Convert.ToInt32(Console.ReadLine());
                bool deleted = false;
                MovieBL movieBLObj = new MovieBL();
                deleted = movieBLObj.DeleteMovies(movieId);
                if (deleted == true)
                {
                    Console.WriteLine("Movie Was deleted !");
                }
                else
                {
                    Console.WriteLine("Movie Was Not deleted !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
