﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer;
using ConsoleTables;
using Entities;
namespace MovieManagement
{
    public class CategoryPL
    {
        public static void ViewCategory()
        {
            Console.Clear();
            List<Category> categoryList = new List<Category>();
            try
            {
                CategoryBL categoryBLObj = new CategoryBL();
                categoryList = categoryBLObj.GetAllCategory();
                var table = new ConsoleTable("Category ID", "Category Name");
                foreach (Category me in categoryList)
                {
                    table.AddRow(me.Id,me.Name);
                }
                table.Write();
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AddCategory()
        {
            Console.Clear();
            Category categoryObj = new Category();
            Console.Write("Please Enter the Name of the New Category : ");
            categoryObj.Name = Console.ReadLine();
            bool added = false;
            try
            {
                CategoryBL categoryBLObj = new CategoryBL();
                added = categoryBLObj.AddCategory(categoryObj);
                if (added==true)
                {
                    Console.WriteLine("New Category is Added into the Database !");
                }
                else
                {
                    Console.WriteLine("New Category is not added !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCategory()
        {
            Console.Clear();
            Category categoryObj = new Category();
            Console.WriteLine("Please Enter the Category Id");
            categoryObj.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter the New Category name !");
            categoryObj.Name = Console.ReadLine();
            
            bool updated = false;
            try
            {
                CategoryBL categoryBLObj = new CategoryBL();
                updated = categoryBLObj.UpdateCategory(categoryObj);
                if (updated == true)
                {
                    Console.WriteLine(categoryObj.Name+" is Updated !");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCategory()
        {
            Console.Clear();
            Console.WriteLine("Please Enter the Category ID to be Deleted");
            Category categoryObj = new Category();
            categoryObj.Id = Convert.ToInt32(Console.ReadLine());
            bool deleted = false;
            try
            {
                CategoryBL categoryBLObj = new CategoryBL();
                deleted = categoryBLObj.DeleteCategory(categoryObj);
                if (deleted == true)
                {
                    Console.WriteLine("Category Was Deleted !");
                }
                else
                {
                    Console.WriteLine("Category Was Not Deleted ");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
