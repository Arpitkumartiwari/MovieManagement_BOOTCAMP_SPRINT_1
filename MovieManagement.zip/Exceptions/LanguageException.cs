﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Exceptions
{
    public class LanguageException : ApplicationException
    {
        public LanguageException() : base()
        {

        }
        public LanguageException(string message) : base(message)
        {

        }
        public LanguageException(string message, Exception exception) : base(message, exception)
        {

        }
    }
}
