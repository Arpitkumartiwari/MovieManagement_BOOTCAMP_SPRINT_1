﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class MovieLanguageException : Exception
    {
        public MovieLanguageException() : base() { }
        public MovieLanguageException(string message) : base(message) { }
        public MovieLanguageException(string message, Exception Ex) : base(message, Ex) { }
    }
}
