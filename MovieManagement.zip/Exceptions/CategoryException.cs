﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class CategoryException : ApplicationException
    {
        public CategoryException() : base()
        {

        }
        public CategoryException(string message) : base(message)
        {

        }
        public CategoryException(string message, Exception exception) : base(message, exception)
        {

        }
    }


}
