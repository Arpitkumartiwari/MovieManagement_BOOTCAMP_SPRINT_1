﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entities;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
namespace BusinessLayer
{
    public class LanguageBL
    {
        LanguageDAL languageDALObj = new LanguageDAL();

        public bool Validate(Language languageEntityObj)
        {
            StringBuilder sb = new StringBuilder();
            bool validate = true;
            if (languageEntityObj.Name == string.Empty)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Language Name Required");
            }
            if (validate == false)
                throw new LanguageException(sb.ToString());
            return validate;
        }
        public List<Language> GetAllLanguageBL()
        {
            List<Language> Le = null;
            try
            {
                Le = languageDALObj.GetAllLanguageDAL();
            }
            catch (LanguageException langEx)
            {
                throw langEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return Le;
        }
        public bool AddLanguageBL(Language languageEntityObj)
        {
            bool addLanguage = false;
            try
            {
                if (Validate(languageEntityObj))
                {
                    addLanguage = languageDALObj.AddLanguage(languageEntityObj);
                }
            }
            catch (LanguageException langEx)
            {
                throw langEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return addLanguage;
        }
        public bool DeleteLanguageBL(Language languageEntityObj)
        {
            bool deleteLanguage = false;
            try
            {
                deleteLanguage = languageDALObj.DeleteLanguage(languageEntityObj);
            }
            catch (LanguageException langEx)
            {
                throw langEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deleteLanguage;
        }
    }
}