﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DAL;
using System.Data;
using System.Data.SqlClient;
using Exceptions;
namespace BusinessLayer
{
    public class UserBL
    {
        UserDAL userDALObj = new UserDAL();
        private bool ValidateUser(User userObj)
        {
            StringBuilder sb = new StringBuilder();
            bool validate = true;
            if (userObj.Name == string.Empty)
            {
                validate = false;
                sb.Append(Environment.NewLine + "User Name is Required");
            }
            if (userObj.Password == string.Empty)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Password is Required");
            }
            if (validate == false)
                throw new UserException(sb.ToString());
            return validate;
        }

        public int LogIn(User userObj)
        {
            int Role = 0;
            try
            {
                if (ValidateUser(userObj))
                    Role = userDALObj.LogIn(userObj);
            }
            catch (UserException userEx)
            {
                throw userEx;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return Role;
        }

        public bool AddCustomer(User userObj)
        {
            bool customerAdded = false;
            try
            {
                if (ValidateUser(userObj))
                {
                    UserDAL userDALObj = new UserDAL();
                    customerAdded = userDALObj.RegisterCustomer(userObj);
                }
            }
            catch (UserException userEx)
            {
                throw userEx;
            }
            return customerAdded;
        }

        public bool AddAdmin(User userObj)
        {
            bool adminAdded = false;
            try
            {
                if (ValidateUser(userObj))
                {
                    UserDAL userDALObj = new UserDAL();
                    adminAdded = userDALObj.RegisterAdmin(userObj);
                }
            }
            catch (UserException userEx)
            {
                throw userEx;
            }
            return adminAdded;
        }

    }
}
