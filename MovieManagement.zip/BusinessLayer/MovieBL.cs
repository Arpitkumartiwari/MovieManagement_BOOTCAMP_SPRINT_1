﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DAL;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
namespace BusinessLayer
{
    public class MovieBL
    {
        private static bool ValidateMovie(Movie movieObj)
        {
            bool movie_validated = true;
            StringBuilder sb = new StringBuilder();
            if (movieObj.Name == null)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Please Enter the Movie Name !");
            }
            if (movieObj.CategoryId < 100)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Invalid Category ID / ");
            }
            if (movieObj.Rating < 0)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Invalid Rating, Please enter the Correct Rating !");
            }
            if (movieObj.LeadActor == null)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Please Enter the Lead Actors of the Movie !");
            }
            if (movieObj.ReleaseYear < 1888)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "1st ever movie was released in 1888, Please Enter the Correct Movie Release Year");
            }
            if (movieObj.Description == null)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Please Enter The Movie Description !");
            }
            if (movieObj.Budget == null)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Please Enter Budget of The Movie !");
            }
            if (movieObj.Duration < 5)
            {
                movie_validated = false;
                sb.Append(Environment.NewLine + "Please Enter the Correct Movie Duration in Minutes");
            }
            return movie_validated;
        }

        public bool AddMovies(Movie movieObj)
        {
            bool moviesAdded = false;
            try
            {
                if (ValidateMovie(movieObj))
                {
                    MovieDAL movieDALObj = new MovieDAL();
                    moviesAdded = movieDALObj.AddMovieDAL(movieObj);
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return moviesAdded;
        }

        public bool UpdateMovies(Movie movieObj)
        {
            bool moviesUpdated = false;
            try
            {
                if (ValidateMovie(movieObj))
                {
                    MovieDAL movieDALObj = new MovieDAL();
                    moviesUpdated = movieDALObj.UpdateMovieDAL(movieObj);
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return moviesUpdated;
        }

        public bool DeleteMovies(int movieId)
        {
            bool moviesDeleted = false;
            try
            {
                if (movieId > 1000)
                {
                    MovieDAL mv = new MovieDAL();
                    moviesDeleted = mv.DeleteMovieDAL(movieId);
                    moviesDeleted = true;
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return moviesDeleted;
        }

        public List<Movie> SearchByCategory(string categoryName)
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.SearchByCategoryDAL(categoryName);
            }
            catch (CategoryException categoryEx)
            {
                throw categoryEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMoviesByRating(double rating)
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.SearchMovieByRatingDAL(rating);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMoviesByReleaseYear(int release_year)
        {
            List<Movie> movieList = new List<Movie>();
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList =  movieDALObj.SearchMovieByReleaseYearDAL(release_year);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMoviesByLeadActor(string actorname)
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.SearchMovieByLeadActorDAL(actorname);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMovieName(string name)
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.SearchMovieByNameDAL(name);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMoviesByLanguage(string language)
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.SearchMovieByLanguageDAL(language);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> ListMovies()
        {
            List<Movie> movieList = null;
            try
            {
                MovieDAL movieDALObj = new MovieDAL();
                movieList = movieDALObj.ListAllMoviesDAL();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieList;
        }
    }
}
