﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Exceptions;
namespace BusinessLayer
{
    public class CategoryBL
    {
        CategoryDAL categoryDALObj = new CategoryDAL();
        public bool Validate(Category categoryEntityObj)
        {
            StringBuilder sb = new StringBuilder();
            bool validate = true;
            if (categoryEntityObj.Name == string.Empty)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Category Name Required");
            }
            if (validate == false)
                throw new CategoryException(sb.ToString());
            return validate;
        }
        public List<Category> GetAllCategory()
        {
            List<Category> Categories = null;
            try
            {
                Categories = categoryDALObj.AllCategory();
            }
            catch (CategoryException categoryEx)
            {
                throw categoryEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return Categories;
        }
        public bool AddCategory(Category categoryEntityObj)
        {
            bool categoryAdded = false;
            try
            {
                if (Validate(categoryEntityObj))
                {
                    categoryAdded = categoryDALObj.InsertCategory(categoryEntityObj);
                }
            }
            catch (CategoryException categoryEx)
            {
                throw categoryEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryAdded;
        }
        public bool UpdateCategory(Category categoryEntityObj)
        {
            bool categoryUpdated = false;
            try
            {
                if (Validate(categoryEntityObj))
                {
                    categoryUpdated = categoryDALObj.UpdateCategory(categoryEntityObj);
                }
            }
            catch (CategoryException categoryEx)
            {
                throw categoryEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryUpdated;
        }
        public bool DeleteCategory(Category categoryEntityObj)
        {
            bool categoryDeleted = false;
            try
            {
                if (Validate(categoryEntityObj))
                {
                    categoryDeleted = categoryDALObj.DeleteCategory(categoryEntityObj);
                }
            }
            catch (CategoryException categoryEx)
            {
                throw categoryEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryDeleted;
        }
    }
}
