﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entities;
using Exceptions;
namespace BusinessLayer
{
    public class MovieLanguageBL
    {
        MovieLanguageDAL movieLanguageDALObj = new MovieLanguageDAL();

        public bool ValidateMovieLanguage(MovieLanguage movieLanguageObj)
        {
            StringBuilder sb = new StringBuilder();
            bool validate = true;
            if (movieLanguageObj.Id < 100)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Enter Correct MovieId");
            }
            if (movieLanguageObj.LanguageID < 1)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Enter Correct LanguageId");
            }
            if (validate == false)
                throw new MovieLanguageException(sb.ToString());
            return validate;
        }

        public bool InsertMovieLanguage(MovieLanguage movieLanguageObj)
        {
            bool movieLanguageAdded = false;
            try
            {
                movieLanguageAdded = movieLanguageDALObj.InsertMovieLanguageDAL(movieLanguageObj);
            }
            catch (MovieLanguageException movielanguageEx)
            {
                throw movielanguageEx;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return movieLanguageAdded;
        }

        public bool UpdateMovieLanguage(MovieLanguage movieLanguageObj)
        {
            bool movieLanguageUpdated = false;
            try
            {
                movieLanguageUpdated = movieLanguageDALObj.UpdateMovieLanguageDAL(movieLanguageObj);
            }
            catch (MovieLanguageException movielanguageEx)
            {
                throw movielanguageEx;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return movieLanguageUpdated;
        }

        public bool DeleteMovieLanguage(int movieLanguageId)
        {
            bool movieLanguageDeleted = false;

            try
            {
                movieLanguageDeleted = movieLanguageDALObj.DeleteMovieLanguageDAL(movieLanguageId);
            }
            catch (MovieLanguageException movieLanguageEX)
            {
                throw movieLanguageEX;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return movieLanguageDeleted;
        }

        public List<MovieLanguage> ListAllMovieLanguage()
        {
            List<MovieLanguage> movieLanguageList = new List<MovieLanguage>();
            try
            {
                movieLanguageList = movieLanguageDALObj.GetAllMovieLanguage();
            }
            catch (MovieLanguageException movieLanguageEx)
            {
                throw movieLanguageEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return movieLanguageList;
        }
    }
}
