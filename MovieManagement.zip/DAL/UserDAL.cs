﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class UserDAL
    {
        SqlConnection sql_Connection = new SqlConnection(MovieManagementConfiguration.ConnectionString);
        public int LogIn(User userObj)
        {
            int Role = 0;
            try
            {
                string procedure = "SPLogin";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;



                SqlParameter param;
                param = sql_Command.Parameters.Add("@Passwd", SqlDbType.VarChar, 50);
                param.Value = userObj.Password;
                param = sql_Command.Parameters.Add("@userName", SqlDbType.VarChar, 50);
                param.Value = userObj.Name;



                sql_Connection.Open();
                SqlDataReader dataReader = sql_Command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                Role = Convert.ToInt32(dataTable.Rows[0][0]);
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Role;
        }

        public bool RegisterCustomer(User userObj)
        {
            bool Registered = false;
            try
            {
                string procedure = "SPRegistration";



                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
                param.Value = userObj.Name;
                param = sql_Command.Parameters.Add("@UserPassword", SqlDbType.VarChar, 50);
                param.Value = userObj.Password;
                param = sql_Command.Parameters.Add("@RoleID", SqlDbType.VarChar, 50);
                param.Value = "R002";
                sql_Connection.Open();
                int rowsaffected = sql_Command.ExecuteNonQuery();
                if (rowsaffected > 0)
                {
                    Registered = true;
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return Registered;
        }

        public bool RegisterAdmin(User userObj)
        {
            bool Registered = false;
            try
            {
                string procedure = "SPRegistration";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
                param.Value = userObj.Name;
                param = sql_Command.Parameters.Add("@UserPassword", SqlDbType.VarChar, 50);
                param.Value = userObj.Password;
                param = sql_Command.Parameters.Add("@RoleID", SqlDbType.VarChar, 50);
                param.Value = "R001";
                sql_Connection.Open();
                int rowsaffected = sql_Command.ExecuteNonQuery();
                if (rowsaffected > 0)
                {
                    Registered = true;
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Registered;

        }
    }
}
