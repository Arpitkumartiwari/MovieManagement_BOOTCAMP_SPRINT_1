﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{

    public class MovieLanguageDAL
    {
        SqlConnection sql_Connection = new SqlConnection(MovieManagementConfiguration.ConnectionString);

        public bool InsertMovieLanguageDAL(MovieLanguage movieLanguageObj)
        {
            bool movieLanguageAdded = false;
            try
            {
                string Procedure = "SPaddMovieLanguage";
                SqlCommand sql_Command = new SqlCommand(Procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@MovieId", SqlDbType.Int);
                param.Value = movieLanguageObj.MovieID;
                param = sql_Command.Parameters.Add("@LanguageId", SqlDbType.Int);
                param.Value = movieLanguageObj.LanguageID;
                sql_Connection.Open();
                int affectedRows = sql_Command.ExecuteNonQuery();
                if (affectedRows > 0)
                    movieLanguageAdded = true;
                sql_Connection.Close();
            }
            catch (SqlException Ex)
            {
                throw Ex;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return movieLanguageAdded;
        }

        public bool UpdateMovieLanguageDAL(MovieLanguage movieLanguageObj)
        {
            bool movieLanghuageUpdated = false;
            try
            {
                string Procedure = "SPupdateMovieLanguage";
                SqlCommand sql_Command = new SqlCommand(Procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@MoviLangId", SqlDbType.Int);
                param.Value = movieLanguageObj.Id;
                param = sql_Command.Parameters.Add("@MovieId", SqlDbType.Int);
                param.Value = movieLanguageObj.MovieID;
                param = sql_Command.Parameters.Add("@LanguageId", SqlDbType.Int);
                param.Value = movieLanguageObj.LanguageID;
                sql_Connection.Open();
                int affectedRows = sql_Command.ExecuteNonQuery();
                if (affectedRows > 0)
                    movieLanghuageUpdated = true;
                sql_Connection.Close();
            }
            catch (SqlException Ex)
            {
                throw Ex;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return movieLanghuageUpdated;
        }

        public bool DeleteMovieLanguageDAL(int movieLanguageId)
        {
            bool delete_movielanguage = false;
            try
            {
                string storeProcedure = "SPdeletemovielang";
                SqlCommand sql_Command = new SqlCommand(storeProcedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;

                param = sql_Command.Parameters.Add("@movielanguagepk", SqlDbType.Int);
                param.Value = movieLanguageId;

                sql_Connection.Open();
                int affected_rows = sql_Command.ExecuteNonQuery();
                if (affected_rows > 0)
                    delete_movielanguage = true;
                sql_Connection.Close();
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return delete_movielanguage;
        }

        public List<MovieLanguage> GetAllMovieLanguage()
        {
            List<MovieLanguage> movieLanguageList = new List<MovieLanguage>();
            try
            {
                string procedure = "SPListAllMovieLanguage";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();
                while (datareader.Read())
                {
                    MovieLanguage movieLanguageObj = new MovieLanguage();
                    movieLanguageObj.Id = (int)datareader[0];
                    movieLanguageObj.MovieID = (int)datareader[1];
                    movieLanguageObj.LanguageID = (int)datareader[2];
                    movieLanguageList.Add(movieLanguageObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieLanguageList;
        }


    }
}
