﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class CategoryDAL
    {
                SqlConnection sql_Connection = new SqlConnection(MovieManagementConfiguration.ConnectionString);
                SqlCommand sql_Command;

        public List<Category> AllCategory()
        {
            Console.Clear();
            Console.WriteLine("Displaying All the Categories with their Categories ID !");
            List<Category> categories = new List<Category>();
            try
            {
                string procedure = "CategoryList";
                sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Category categoryEntityObj = new Category();
                    categoryEntityObj.Id = (int)datareader[0];
                    categoryEntityObj.Name = (string)datareader[1];
                    categories.Add(categoryEntityObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categories;
        }

        public bool InsertCategory(Category categoryEntityObj)
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Add Category Portal");
            bool addCategory = false;
            try
            {
                string procedure = "InsertCategory";
                sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@CategoryName", SqlDbType.VarChar, 50);
                param.Value = categoryEntityObj.Name;
                sql_Connection.Open();
                int affectedRows = sql_Command.ExecuteNonQuery();
                if (affectedRows > 0)
                    addCategory = true;
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return addCategory;
        }

        public bool UpdateCategory(Category categoryEntityObj)
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Update Category Portal");
            bool updateCategory = false;
            try
            {
                string procedure = "UpdateCategory";
                sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@CategoryID", SqlDbType.Int);
                param.Value = categoryEntityObj.Id;
                param = sql_Command.Parameters.Add("@CategoryName", SqlDbType.VarChar, 50);
                param.Value = categoryEntityObj.Name;
                sql_Connection.Open();
                int affectecRows = sql_Command.ExecuteNonQuery();
                if (affectecRows > 0)
                    updateCategory = true;
                sql_Connection.Close();
            }
            catch(SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return updateCategory;
        }

        public bool DeleteCategory(Category categoryEntityObj)
        {
            Console.Clear();
            Console.WriteLine("Welcome to the delete Category Portal");
            bool deleteCategory = false;
            try
            {
                string procedure = "DeleteCategory";
                sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@CategoryID", SqlDbType.Int);
                param.Value = categoryEntityObj.Id;
                sql_Connection.Open();
                int affectecRows = sql_Command.ExecuteNonQuery();
                if (affectecRows > 0)
                    deleteCategory = true;
                sql_Connection.Close();
            }
            catch(SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deleteCategory;
        }
        
    }
}
