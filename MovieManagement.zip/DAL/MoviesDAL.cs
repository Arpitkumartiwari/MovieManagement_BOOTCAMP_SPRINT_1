﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;

namespace DAL
{
    public class MovieDAL
    {
        SqlConnection sql_Connection;

        public MovieDAL()
        {
            sql_Connection  = new SqlConnection(MovieManagementConfiguration.ConnectionString);
        }
        public bool AddMovieDAL(Movie movieObj)
        {
            bool movieAdded = false;

            try
            {
                string procedure = "Addmovie";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;


                SqlParameter param = sql_Command.Parameters.Add("@moviename", SqlDbType.VarChar, 50);
                param.Value = movieObj.Name;
                

                param = sql_Command.Parameters.Add("@moviecatid", SqlDbType.Int);
                param.Value = movieObj.CategoryId;

                param = sql_Command.Parameters.Add("@movierating", SqlDbType.Float);
                param.Value = movieObj.Rating;

                param = sql_Command.Parameters.Add("@leadactor", SqlDbType.VarChar, 500);
                param.Value = movieObj.LeadActor;

                param = sql_Command.Parameters.Add("@releaseyear", SqlDbType.Int);
                param.Value = movieObj.ReleaseYear;

                param = sql_Command.Parameters.Add("@moviedescription", SqlDbType.VarChar, 500);
                param.Value = movieObj.Description;

                param = sql_Command.Parameters.Add("@moviebudget", SqlDbType.VarChar,50);
                param.Value = movieObj.Budget;

                param = sql_Command.Parameters.Add("@movieduration", SqlDbType.Int);
                param.Value = movieObj.Duration;
                sql_Connection.Open();
                int affected_rows = sql_Command.ExecuteNonQuery();
                if (affected_rows>0)
                {
                    movieAdded = true;
                }
                sql_Connection.Close();
            }
            catch(SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieAdded;
        }

        public bool UpdateMovieDAL(Movie movieObj)
        {
            bool movieupdated = false;
            try
            {
                string procedure = "updatemovie";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;

                param = sql_Command.Parameters.Add("@movieid", SqlDbType.Int);
                param.Value = movieObj.Id;

                param = sql_Command.Parameters.Add("@moviename", SqlDbType.VarChar, 50);
                param.Value = movieObj.Name;

                param = sql_Command.Parameters.Add("@moviecatid", SqlDbType.Int);
                param.Value = movieObj.CategoryId;

                param = sql_Command.Parameters.Add("@movierating", SqlDbType.Float);
                param.Value = movieObj.Rating;

                param = sql_Command.Parameters.Add("@leadactor", SqlDbType.VarChar, 500);
                param.Value = movieObj.LeadActor;

                param = sql_Command.Parameters.Add("@releaseyear", SqlDbType.Int);
                param.Value = movieObj.ReleaseYear;

                param = sql_Command.Parameters.Add("@moviedescription", SqlDbType.VarChar, 500);
                param.Value = movieObj.Description;

                param = sql_Command.Parameters.Add("@moviebudget", SqlDbType.VarChar, 50);
                param.Value = movieObj.Budget;

                param = sql_Command.Parameters.Add("@movieduration", SqlDbType.Int);
                param.Value = movieObj.Duration;

                sql_Connection.Open();
                int affected_rows = sql_Command.ExecuteNonQuery();
                if (affected_rows > 0)
                {
                    movieupdated = true;
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return movieupdated;
        }

        public bool DeleteMovieDAL(int deletemovieid)
        {
            bool moviedeleted = false;
            try
            {
                string procedure = "SPdeletemovie";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@movieid", SqlDbType.Int);
                param.Value = deletemovieid;
                sql_Connection.Open();
                int affectedrow = sql_Command.ExecuteNonQuery();
                if (affectedrow>0)
                {
                    moviedeleted = true;
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return moviedeleted;
        }

        public List<Movie> ListAllMoviesDAL()
        {
            List<Movie> movieList = new List<Movie>();
            try
            {
                string procedure = "SPlistallmovies";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;

                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Id = (int)datareader[0];
                    movieObj.Name = (string)datareader[1];
                    movieObj.CategoryName = (string)datareader[2];
                    movieObj.Rating = (double)datareader[3];
                    movieObj.LeadActor = (string)datareader[4];
                    movieObj.ReleaseYear = (int)datareader[5];
                    movieObj.Description = (string)datareader[6];
                    movieObj.Budget = (string)datareader[7];
                    movieObj.Duration = (int)datareader[8];
                    movieList.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch(SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return movieList;
        }

        public List<Movie> SearchMovieByLanguageDAL(string language)
        {
            List<Movie> Movies = new List<Movie>();
            try
            {
                string procedure = "searchlanguage";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@language", SqlDbType.VarChar, 50);
                param.Value = language;

                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    Movies.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Movies;
        }

        public List<Movie> SearchMovieByReleaseYearDAL(int year)
        {
            List<Movie> Movies = new List<Movie>();
            try
            {
                string procedure = "searchyear";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@year", SqlDbType.Int);
                param.Value = year;
                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    Movies.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Movies;
        }

        public List<Movie> SearchByCategoryDAL(string category)
        {
            List<Movie> category_Movie = new List<Movie>();
            try
            {
                string procedure = "SearchMovieByCategory";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@CategoryName", SqlDbType.VarChar, 50);
                param.Value = category;
                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    category_Movie.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            return category_Movie;
        }

        public List<Movie> SearchMovieByLeadActorDAL(string lead_actor)
        {
            List<Movie> searchMovieByActor = new List<Movie>();
            try
            {
                string procedure = "SPsearchleadactor";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@leadactor", SqlDbType.VarChar, 50);
                param.Value = lead_actor;

                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    searchMovieByActor.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchMovieByActor;

        }

        public List<Movie> SearchMovieByNameDAL(string name)
        {
            List<Movie> searchName = new List<Movie>();
            try
            {
                string procedure = "SPSearchByName";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@name", SqlDbType.VarChar, 50);
                param.Value = name;

                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    searchName.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchName;
        }

        public List<Movie> SearchMovieByRatingDAL(double rating)
        {
            List<Movie> searchMovieByRatingDAL = new List<Movie>();
            try
            {
                string procedure = "SPsearchbyrating";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param;
                param = sql_Command.Parameters.Add("@rating", SqlDbType.Float);
                param.Value = rating;

                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();

                while (datareader.Read())
                {
                    Movie movieObj = new Movie();
                    movieObj.Name = (string)datareader[0];
                    movieObj.CategoryName = (string)datareader[1];
                    movieObj.Rating = (double)datareader[2];
                    movieObj.LeadActor = (string)datareader[3];
                    movieObj.ReleaseYear = (int)datareader[4];
                    movieObj.Description = (string)datareader[5];
                    movieObj.Budget = (string)datareader[6];
                    movieObj.Duration = (int)datareader[7];
                    searchMovieByRatingDAL.Add(movieObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchMovieByRatingDAL;
        }
    }
}
