﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace DAL
{
    public class MovieManagementConfiguration
    {
        private static string connectionString;
        public static string ConnectionString
        {
            get { return MovieManagementConfiguration.connectionString; }
            set { MovieManagementConfiguration.connectionString = value; }
        }

        static MovieManagementConfiguration()
        {

            connectionString = ConfigurationManager.ConnectionStrings["movieDatabaseConnection"].ConnectionString;

        }
    }
}
