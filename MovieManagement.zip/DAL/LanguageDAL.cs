﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
namespace DAL
{
    public class LanguageDAL
    {
            SqlConnection sql_Connection = new SqlConnection(MovieManagementConfiguration.ConnectionString);
            
        public bool AddLanguage(Language languageObj)
        {
            bool addLanguage = false;
            try
            {
                string procedure = "AddLanguage";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@LanguageName", SqlDbType.VarChar, 50);
                param.Value = languageObj.Name;
                sql_Connection.Open();
                int affectedRows = sql_Command.ExecuteNonQuery();
                if (affectedRows > 0)
                    addLanguage = true;
                sql_Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return addLanguage;

        }
        public List<Language> GetAllLanguageDAL()
        {
            List<Language> Languages = new List<Language>();
            try
            {
                string procedure = "ShowLanguage"; 
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                sql_Connection.Open();
                SqlDataReader datareader = sql_Command.ExecuteReader();
                while (datareader.Read())
                {
                    Language languageEntityObj = new Language();
                    languageEntityObj.Id = (int)datareader[0];
                    languageEntityObj.Name = (string)datareader[1];
                    Languages.Add(languageEntityObj);
                }
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return Languages;
        }
        public bool DeleteLanguage(Language languageEntityObj)
        {
            bool delLanguage = false;
            try
            {
                string procedure = "DeleteLanguage";
                SqlCommand sql_Command = new SqlCommand(procedure, sql_Connection);
                sql_Command.CommandType = CommandType.StoredProcedure;
                SqlParameter param = sql_Command.Parameters.Add("@LanguageID", SqlDbType.Int);
                param.Value = languageEntityObj.Id;
                sql_Connection.Open();
                int affectedRows = sql_Command.ExecuteNonQuery();
                if (affectedRows > 0)
                    delLanguage = true;
                sql_Connection.Close();
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return delLanguage;

        }
    }
}

